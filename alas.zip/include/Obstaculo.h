#pragma once
#include "pch.h"
#include "Jogador.h"

namespace Alaska
{
    namespace Entidades
    {
        namespace Obstaculos
        {
            class Obstaculo : public Entidade
            {
                protected:
                    bool danoso;
                public:
                    Obstaculo(float x, float y);
                    ~Obstaculo();
                    virtual void executar() = 0;
            };
        }
    }
}
